from typing import List


class Utils:

    @staticmethod
    def join_strings(str_list: List[str]) -> str:
        return ",".join(str_list)
